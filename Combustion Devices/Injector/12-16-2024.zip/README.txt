when naming files:
<PART NAME> <REV#>

the files' folder should be named:
<DATE>

and the parent folder should be named
<SUBCOMPONENT>

which resides in a folder:
<SUBSYSTEM>